
import { GoogleGenAI, Type } from "@google/genai";
import { RecommendationResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getSmartRecommendation(mood: string): Promise<RecommendationResponse | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `O humor ou vibe atual do usuário é: "${mood}". Sugira um tipo de bebida batida (shake, smoothie ou coquetel) que combine perfeitamente com esse estado de espírito. Seja criativo e responda estritamente em português.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            drinkName: { type: Type.STRING, description: "Um nome criativo para a bebida recomendada." },
            reason: { type: Type.STRING, description: "Por que esta bebida combina com o humor do usuário." },
            suggestedAddon: { type: Type.STRING, description: "Uma sugestão de cobertura ou ingrediente extra." }
          },
          required: ["drinkName", "reason", "suggestedAddon"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text.trim()) as RecommendationResponse;
    }
    return null;
  } catch (error) {
    console.error("Erro na API Gemini:", error);
    return null;
  }
}
