
import React, { useEffect, useState } from 'react';
import { ShoppingBag, Search, Sparkles } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onScrollToAI: () => void;
}

export const Header: React.FC<HeaderProps> = ({ cartCount, onOpenCart, onScrollToAI }) => {
  const [isPopping, setIsPopping] = useState(false);

  useEffect(() => {
    if (cartCount > 0) {
      setIsPopping(true);
      const timer = setTimeout(() => setIsPopping(false), 400);
      return () => clearTimeout(timer);
    }
  }, [cartCount]);

  return (
    <header className="sticky top-0 z-40 w-full glass-card border-b border-orange-100/50">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-amber-600 rounded-lg flex items-center justify-center text-white font-bold text-2xl shadow-xl shadow-amber-200/50">
            V
          </div>
          <span className="text-xl font-extrabold tracking-tighter text-amber-950 hidden sm:block">
            VERVE <span className="font-light text-amber-600">NATURAL</span>
          </span>
        </div>

        <div className="flex-1 max-w-md mx-8 hidden lg:block">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-300" />
            <input 
              type="text" 
              placeholder="Explorar sabores premium..." 
              className="w-full bg-orange-50/40 border border-orange-100/50 rounded-xl py-2.5 pl-11 pr-4 focus:ring-2 focus:ring-amber-500/20 outline-none text-sm transition-all placeholder:text-amber-200"
            />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <button 
            onClick={onScrollToAI}
            className="flex items-center gap-2 text-amber-700 font-semibold px-5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 transition-all text-sm border border-amber-100/50"
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">IA Concierge</span>
          </button>
          
          <button 
            id="cart-button-ref"
            onClick={onOpenCart}
            className={`relative p-2.5 text-amber-950 hover:bg-amber-50 rounded-xl transition-all ${isPopping ? 'animate-cart-pop' : ''}`}
          >
            <ShoppingBag className={`w-6 h-6 ${cartCount > 0 ? 'text-amber-600' : 'text-amber-950'}`} />
            {cartCount > 0 && (
              <span className="absolute top-1.5 right-1.5 bg-amber-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white shadow-lg">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
