
import React, { useState, useRef } from 'react';
import { Star, Plus, Minus, Heart, Zap, Info, Check, Share2, Eye } from 'lucide-react';
import { Drink, ExtraIngredient } from '../types';
import { EXTRA_INGREDIENTS } from '../constants';
import { DrinkDetailsModal } from './DrinkDetailsModal';

interface DrinkCardProps {
  drink: Drink;
  onAddToCart: (drink: Drink, extras: ExtraIngredient[], quantity: number) => void;
  onBuyNow: (drink: Drink, extras: ExtraIngredient[], quantity: number) => void;
  quantityInCart: number;
  onRemoveFromCart: (drinkId: string) => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export const DrinkCard: React.FC<DrinkCardProps> = ({ 
  drink, 
  onAddToCart, 
  onBuyNow,
  quantityInCart, 
  isFavorite,
  onToggleFavorite
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedExtras, setSelectedExtras] = useState<ExtraIngredient[]>([]);
  const [localQuantity, setLocalQuantity] = useState(1);
  const [isAdding, setIsAdding] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const toggleExtra = (extra: ExtraIngredient) => {
    setSelectedExtras(prev => {
      if (prev.find(e => e.id === extra.id)) {
        return prev.filter(e => e.id !== extra.id);
      }
      if (prev.length < 2) return [...prev, extra];
      return prev;
    });
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.share({
        title: `Verve Natural | ${drink.name}`,
        text: `Descubra o sabor impecável do ${drink.name} no Verve Natural.`,
        url: window.location.href,
      });
    } catch (err) {
      console.error('Share error:', err);
    }
  };

  const handleAddToCartClick = () => {
    if (isAdding) return;
    setIsAdding(true);
    onAddToCart(drink, selectedExtras, localQuantity);
    setSelectedExtras([]);
    setLocalQuantity(1);
    setTimeout(() => setIsAdding(false), 800);
  };

  const unitPrice = drink.price + selectedExtras.reduce((sum, e) => sum + e.price, 0);
  const totalPrice = unitPrice * localQuantity;

  return (
    <>
      <div className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all duration-500 border border-orange-50 flex flex-col h-full relative">
        <div className="relative h-56 overflow-hidden">
          <img 
            src={drink.image} 
            alt={drink.name}
            onLoad={() => setIsLoaded(true)}
            className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
          />
          <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
            <button onClick={onToggleFavorite} className="p-2.5 rounded-full bg-white/90 backdrop-blur-md shadow-sm text-amber-900 transition-all hover:bg-white active:scale-90">
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-amber-600 text-amber-600' : ''}`} />
            </button>
            <button onClick={handleShare} className="p-2.5 rounded-full bg-white/90 backdrop-blur-md shadow-sm text-amber-900 transition-all hover:bg-white active:scale-90">
              <Share2 className="w-4 h-4" />
            </button>
          </div>
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span className="text-xs font-bold text-amber-950">{drink.rating}</span>
          </div>
          <div className="absolute bottom-4 left-4">
            <span className="bg-amber-950/80 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1.5 rounded-lg uppercase tracking-widest">
              {drink.category}
            </span>
          </div>
        </div>

        <div className="p-6 flex flex-col flex-1">
          <h3 className="text-xl font-bold text-amber-950 mb-2 leading-tight">{drink.name}</h3>
          <p className="text-amber-900/60 text-sm mb-6 line-clamp-2 font-medium">{drink.description}</p>

          <div className="mb-6 space-y-3">
            <div className="flex justify-between items-center text-[10px] font-bold text-amber-900/40 uppercase tracking-widest">
              <span>Personalizar</span>
              <span>{selectedExtras.length}/2</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {EXTRA_INGREDIENTS.map(extra => {
                const isSelected = selectedExtras.find(e => e.id === extra.id);
                return (
                  <button
                    key={extra.id}
                    onClick={() => toggleExtra(extra)}
                    className={`flex flex-col items-center gap-1.5 p-2 rounded-xl border transition-all ${
                      isSelected ? 'bg-amber-50 border-amber-500 shadow-sm' : 'bg-white border-amber-100/30 hover:border-amber-200'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg overflow-hidden border border-amber-100">
                      <img src={extra.image} className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[9px] font-bold text-amber-900/80 truncate w-full text-center">{extra.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-auto pt-6 border-t border-amber-50 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 bg-amber-50/50 p-1.5 rounded-lg border border-amber-100">
                <button onClick={() => setLocalQuantity(Math.max(1, localQuantity - 1))} className="w-6 h-6 flex items-center justify-center text-amber-900 hover:bg-white rounded-md transition-all">
                  <Minus className="w-3 h-3" />
                </button>
                <span className="text-xs font-bold min-w-[20px] text-center">{localQuantity}</span>
                <button onClick={() => setLocalQuantity(localQuantity + 1)} className="w-6 h-6 flex items-center justify-center text-amber-900 hover:bg-white rounded-md transition-all">
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <div className="text-right">
                <span className="text-[10px] block text-amber-900/40 font-bold uppercase tracking-widest">Preço</span>
                <span className="text-xl font-black text-amber-950">R$ {totalPrice.toFixed(2)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={handleAddToCartClick}
                className={`py-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                  isAdding ? 'bg-emerald-600 text-white' : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
                }`}
              >
                {isAdding ? <Check className="w-4 h-4" /> : 'Adicionar'}
              </button>
              <button 
                onClick={() => onBuyNow(drink, selectedExtras, localQuantity)}
                className="bg-amber-600 text-white py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 hover:bg-amber-700 shadow-lg shadow-amber-200/50 transition-all active:scale-95"
              >
                <Zap className="w-3.5 h-3.5 fill-white" />
                Comprar
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
