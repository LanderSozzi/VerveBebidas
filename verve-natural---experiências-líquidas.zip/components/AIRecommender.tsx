
import React, { useState } from 'react';
import { Sparkles, Loader2, Wand2, BrainCircuit, Lightbulb, Zap } from 'lucide-react';
import { getSmartRecommendation } from '../services/geminiService';
import { RecommendationResponse } from '../types';

export const AIRecommender: React.FC = () => {
  const [mood, setMood] = useState('');
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<RecommendationResponse | null>(null);

  const handleRecommend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mood.trim()) return;

    setLoading(true);
    const result = await getSmartRecommendation(mood);
    setRecommendation(result);
    setLoading(false);
  };

  const quickMoods = ['Foco Total 🧠', 'Zen & Calmo 🌊', 'Energia Pós-Treino 🏋️', 'Noite de Festa 🕺', 'Dia de Calor ☀️'];

  return (
    <section id="ai-mixer" className="max-w-7xl mx-auto px-4 py-24">
      <div className="relative rounded-[4rem] overflow-hidden bg-orange-950 border border-orange-400/20 shadow-[0_32px_64px_-16px_rgba(251,146,60,0.3)]">
        {/* Background Effects */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-[120px]" />
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2">
          <div className="p-8 md:p-20 space-y-10">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 bg-orange-500/10 text-orange-400 px-4 py-2 rounded-2xl border border-orange-500/20">
                <BrainCircuit className="w-5 h-5" />
                <span className="text-xs font-black uppercase tracking-[0.2em]">Neural Glow v2.0</span>
              </div>
              <h2 className="text-4xl md:text-6xl font-black text-white leading-tight">
                O Gole que <br />
                <span className="text-amber-400">Radiante Você.</span>
              </h2>
              <p className="text-orange-100/60 text-lg leading-relaxed">
                Nossa IA processa seu brilho emocional para sugerir a combinação exata de nutrientes e sabores que aquecem sua alma agora.
              </p>
            </div>

            <form onSubmit={handleRecommend} className="space-y-8">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-orange-500 to-amber-500 rounded-3xl blur opacity-25 group-focus-within:opacity-50 transition duration-500" />
                <div className="relative">
                  <textarea 
                    value={mood}
                    onChange={(e) => setMood(e.target.value)}
                    placeholder="Como está sua vibração hoje? (ex: Precisando de energia solar...)"
                    className="w-full bg-orange-950/80 border border-orange-400/20 rounded-3xl py-6 pl-8 pr-20 text-white placeholder-orange-800 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all text-lg min-h-[140px] resize-none"
                  />
                  <button 
                    type="submit"
                    disabled={loading || !mood.trim()}
                    className="absolute right-4 bottom-4 bg-orange-600 text-white p-4 rounded-2xl hover:bg-orange-500 disabled:bg-orange-900 disabled:opacity-50 transition-all flex items-center justify-center shadow-xl shadow-orange-600/20"
                  >
                    {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Wand2 className="w-6 h-6" />}
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-xs font-bold text-orange-400/60 uppercase tracking-widest flex items-center gap-2">
                  <Lightbulb className="w-4 h-4" />
                  Vibes Rápidas
                </p>
                <div className="flex flex-wrap gap-2">
                  {quickMoods.map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setMood(m)}
                      className="bg-white/5 hover:bg-white/10 text-orange-300 hover:text-white text-sm py-2.5 px-6 rounded-2xl border border-white/5 transition-all"
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </form>
          </div>

          <div className="relative bg-orange-950/50 p-8 md:p-20 flex items-center justify-center border-l border-white/5">
            {!recommendation && !loading && (
              <div className="text-center space-y-6 max-w-sm animate-pulse">
                <div className="w-24 h-24 bg-orange-900/50 rounded-[2rem] border border-orange-400/10 mx-auto flex items-center justify-center text-orange-700">
                  <Zap className="w-10 h-10" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-xl font-bold text-orange-700">Aguardando Brilho...</h4>
                  <p className="text-orange-900 text-sm">Diga-nos sua vibe para que a IA possa processar seu calor.</p>
                </div>
              </div>
            )}

            {loading && (
              <div className="flex flex-col items-center gap-6 text-center">
                <div className="relative">
                  <div className="w-24 h-24 border-4 border-orange-500/20 border-t-orange-500 rounded-full animate-spin" />
                  <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-amber-400 animate-pulse" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-2xl font-bold text-white">Sintonizando Frequências...</h4>
                  <p className="text-orange-200/60">Harmonizando o sol perfeito para seu momento.</p>
                </div>
              </div>
            )}

            {recommendation && !loading && (
              <div className="w-full bg-gradient-to-br from-orange-600 to-amber-600 rounded-[3rem] p-10 shadow-2xl animate-in zoom-in-95 duration-500 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-20">
                   <BrainCircuit className="w-32 h-32 text-white" />
                </div>
                <div className="relative space-y-8">
                  <div className="space-y-2">
                    <span className="text-white/60 font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      Brilho Identificado
                    </span>
                    <h3 className="text-4xl font-black text-white leading-tight">{recommendation.drinkName}</h3>
                  </div>
                  
                  <div className="p-6 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                    <p className="text-white text-lg leading-relaxed italic">"{recommendation.reason}"</p>
                  </div>

                  <div className="flex flex-col gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-white">
                        <Zap className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-white/50 uppercase">Topping Radiante</p>
                        <p className="text-white font-bold">{recommendation.suggestedAddon}</p>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => document.getElementById('menu-section')?.scrollIntoView({ behavior: 'smooth' })}
                    className="w-full bg-white text-orange-700 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-orange-50 transition-colors shadow-xl"
                  >
                    Adicionar ao Pedido
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
