
import React from 'react';
import { X, Info, MapPin, ChefHat, Star, Clock } from 'lucide-react';
import { Drink } from '../types';

interface DrinkDetailsModalProps {
  drink: Drink;
  isOpen: boolean;
  onClose: () => void;
}

export const DrinkDetailsModal: React.FC<DrinkDetailsModalProps> = ({ drink, isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-orange-950/60 backdrop-blur-md animate-in fade-in duration-300"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-2xl bg-white rounded-[2.5rem] overflow-hidden shadow-2xl animate-in zoom-in-95 slide-in-from-bottom-10 duration-500">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 p-2 bg-white/80 backdrop-blur-md hover:bg-white rounded-full text-orange-500 transition-all shadow-lg active:scale-90"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="flex flex-col md:flex-row h-full max-h-[90vh] overflow-y-auto">
          {/* Image Section */}
          <div className="md:w-1/2 relative h-64 md:h-auto">
            <img 
              src={drink.image} 
              alt={drink.name} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-orange-950/50 via-transparent to-transparent md:bg-gradient-to-r" />
            <div className="absolute bottom-6 left-6 text-white">
              <span className="bg-orange-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest mb-2 inline-block">
                {drink.category}
              </span>
              <h2 className="text-3xl font-black">{drink.name}</h2>
            </div>
          </div>

          {/* Info Section */}
          <div className="md:w-1/2 p-8 space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-100">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span className="text-sm font-bold text-amber-700">{drink.rating} / 5.0</span>
              </div>
              <div className="flex items-center gap-1.5 bg-orange-50 px-3 py-1.5 rounded-xl border border-orange-100">
                <Clock className="w-4 h-4 text-orange-500" />
                <span className="text-sm font-bold text-orange-700">Preparo Glow</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3 text-gray-900">
                <div className="p-2 bg-orange-50 rounded-xl text-orange-600">
                  <ChefHat className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold">Segredo do Preparo</h3>
              </div>
              <p className="text-gray-500 text-sm leading-relaxed">
                {drink.preparation || "Nossa equipe utiliza tecnologia de calibração térmica para manter o frescor solar de cada ingrediente."}
              </p>
            </div>

            <div className="pt-4 border-t border-orange-50">
              <h4 className="text-xs font-bold text-orange-400 uppercase tracking-widest mb-4">Composição Radiante</h4>
              <div className="flex flex-wrap gap-2">
                {drink.ingredients.map((ing) => (
                  <span key={ing} className="px-3 py-1.5 bg-orange-50 text-orange-600 text-xs font-medium rounded-xl border border-orange-100">
                    {ing}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
