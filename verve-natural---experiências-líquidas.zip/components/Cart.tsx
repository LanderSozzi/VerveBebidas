
import React, { useState } from 'react';
import { 
  X, ShoppingBag, Trash2, Plus, Minus, CreditCard, Sparkles, 
  PackageCheck, Truck, Clock, CheckCircle, QrCode, Banknote, 
  ChevronRight, Wallet, Trophy
} from 'lucide-react';
import { CartItem, ExtraIngredient } from '../types';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (uniqueId: string, delta: number) => void;
  onRemove: (uniqueId: string) => void;
  onNavigateToAI?: () => void;
}

type OrderState = 'idle' | 'sent' | 'tracking';
type PaymentMethod = 'card' | 'pix' | 'cash' | null;

export const Cart: React.FC<CartProps> = ({ 
  isOpen, 
  onClose, 
  items, 
  onUpdateQuantity, 
  onRemove,
  onNavigateToAI
}) => {
  const [orderState, setOrderState] = useState<OrderState>('idle');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(null);

  const subtotal = items.reduce((sum, item) => sum + (item.totalPricePerUnit * item.quantity), 0);
  const delivery = subtotal > 0 ? 5.00 : 0;
  const total = subtotal + delivery;

  const generateCartItemId = (item: CartItem) => {
    const extraIds = item.selectedExtras.map(e => e.id).sort().join('-');
    return extraIds ? `${item.id}-${extraIds}` : item.id;
  };

  const handleCheckout = () => {
    if (!paymentMethod) return;
    setIsProcessing(true);
    // Simular chamada de API
    setTimeout(() => {
      setIsProcessing(false);
      setOrderState('sent');
    }, 1500);
  };

  const handleTrack = () => {
    setOrderState('tracking');
  };

  const getPaymentLabel = (method: PaymentMethod) => {
    switch (method) {
      case 'card': return 'Cartão (na entrega)';
      case 'pix': return 'PIX';
      case 'cash': return 'Dinheiro';
      default: return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div 
        className="absolute inset-0 bg-orange-900/40 backdrop-blur-sm animate-in fade-in duration-300"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-500">
        <div className="p-6 border-b border-orange-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-6 h-6 text-orange-600" />
            <h2 className="text-xl font-bold text-gray-900">Seu Brilho</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-orange-50 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-orange-300" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
              <div className="relative mb-6">
                <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center animate-pulse">
                  <ShoppingBag className="w-10 h-10 text-orange-200" />
                </div>
                <div className="absolute -top-1 -right-1 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                </div>
              </div>

              <h3 className="text-xl font-bold text-gray-900 mb-3">Sua jornada radiante começa aqui!</h3>
              
              <p className="text-gray-500 mb-10 text-sm leading-relaxed max-w-[280px]">
                Explore nossas <span className="text-orange-600 font-bold">Bebidas em Destaque</span> ou deixe o <span className="text-orange-600 font-bold">Mixer Inteligente</span> encontrar o glow perfeito.
              </p>

              <div className="space-y-3 w-full max-w-[260px]">
                <button 
                  onClick={onClose}
                  className="w-full bg-orange-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-700 transition-all flex items-center justify-center gap-3 group"
                >
                  <Trophy className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  Ver Destaques
                </button>
                
                <button 
                  onClick={() => {
                    onClose();
                    if (onNavigateToAI) onNavigateToAI();
                  }}
                  className="w-full bg-white border border-orange-200 text-orange-700 py-4 rounded-2xl font-bold hover:bg-orange-50 transition-all flex items-center justify-center gap-3 group"
                >
                  <Sparkles className="w-5 h-5 text-orange-500 group-hover:rotate-12 transition-transform" />
                  Mixer Inteligente
                </button>
              </div>
            </div>
          ) : (
            <div className={`space-y-6 transition-opacity duration-300 ${orderState !== 'idle' ? 'opacity-40 pointer-events-none' : 'opacity-100'}`}>
              {items.map(item => {
                const uniqueId = generateCartItemId(item);
                return (
                  <div key={uniqueId} className="flex gap-4">
                    <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 border border-orange-50">
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <h4 className="font-bold text-gray-900">{item.name}</h4>
                        <button 
                          onClick={() => onRemove(uniqueId)}
                          className="text-orange-200 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      
                      {item.selectedExtras.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-2">
                          {item.selectedExtras.map(ex => (
                            <span key={ex.id} className="text-[9px] bg-orange-50 text-orange-600 px-1.5 py-0.5 rounded flex items-center gap-1">
                              <Sparkles className="w-2 h-2" />
                              {ex.name} (+R${ex.price.toFixed(2)})
                            </span>
                          ))}
                        </div>
                      )}

                      <p className="text-orange-600 font-bold mb-3">R$ {item.totalPricePerUnit.toFixed(2)}</p>
                      
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => onUpdateQuantity(uniqueId, -1)}
                          className="w-7 h-7 flex items-center justify-center border border-orange-100 rounded-lg hover:bg-orange-50"
                        >
                          <Minus className="w-3 h-3 text-orange-400" />
                        </button>
                        <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                        <button 
                          onClick={() => onUpdateQuantity(uniqueId, 1)}
                          className="w-7 h-7 flex items-center justify-center border border-orange-100 rounded-lg hover:bg-orange-50"
                        >
                          <Plus className="w-3 h-3 text-orange-400" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="p-6 bg-orange-50/30 border-t border-orange-100 space-y-4 shadow-[0_-10px_20px_-10px_rgba(251,146,60,0.1)]">
            {orderState === 'idle' && (
              <>
                <div className="space-y-4 mb-6">
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest flex items-center gap-2">
                      <Wallet className="w-3 h-3" />
                      Forma de Pagamento
                    </span>
                    <div className="grid grid-cols-3 gap-2">
                      <button 
                        onClick={() => setPaymentMethod('card')}
                        className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl border transition-all ${
                          paymentMethod === 'card' 
                          ? 'bg-orange-600 border-orange-600 text-white shadow-md' 
                          : 'bg-white border-orange-100 text-orange-400 hover:border-orange-300 hover:text-orange-600'
                        }`}
                      >
                        <CreditCard className="w-5 h-5" />
                        <span className="text-[10px] font-bold">Cartão</span>
                      </button>
                      <button 
                        onClick={() => setPaymentMethod('pix')}
                        className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl border transition-all ${
                          paymentMethod === 'pix' 
                          ? 'bg-orange-600 border-orange-600 text-white shadow-md' 
                          : 'bg-white border-orange-100 text-orange-400 hover:border-orange-300 hover:text-orange-600'
                        }`}
                      >
                        <QrCode className="w-5 h-5" />
                        <span className="text-[10px] font-bold">PIX</span>
                      </button>
                      <button 
                        onClick={() => setPaymentMethod('cash')}
                        className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl border transition-all ${
                          paymentMethod === 'cash' 
                          ? 'bg-orange-600 border-orange-600 text-white shadow-md' 
                          : 'bg-white border-orange-100 text-orange-400 hover:border-orange-300 hover:text-orange-600'
                        }`}
                      >
                        <Banknote className="w-5 h-5" />
                        <span className="text-[10px] font-bold">Dinheiro</span>
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 py-4 border-t border-orange-100">
                    <div className="flex justify-between text-gray-500 text-sm">
                      <span>Subtotal</span>
                      <span>R$ {subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-500 text-sm">
                      <span>Entrega</span>
                      <span>R$ {delivery.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-900 text-lg font-black pt-2">
                      <span>Total</span>
                      <span>R$ {total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={handleCheckout}
                  disabled={isProcessing || !paymentMethod}
                  className="w-full bg-orange-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl hover:bg-orange-700 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed group"
                >
                  {isProcessing ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : !paymentMethod ? (
                    <span className="text-sm">Selecione o Pagamento</span>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      <span className="text-sm">Finalizar Pedido</span>
                    </>
                  )}
                </button>
              </>
            )}

            {orderState === 'sent' && (
              <div className="animate-in fade-in zoom-in-95 duration-500 space-y-4">
                <div className="bg-amber-50 border border-amber-100 p-6 rounded-[2rem] flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-amber-500 text-white rounded-full flex items-center justify-center mb-4 shadow-lg shadow-amber-200 animate-bounce-subtle">
                    <PackageCheck className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold text-amber-900">Pedido Enviado!</h3>
                  <p className="text-sm text-amber-600 mt-1">Sua bebida já está sendo preparada com todo carinho radiante.</p>
                </div>
                
                <button 
                  onClick={handleTrack}
                  className="w-full bg-white border border-amber-200 text-amber-900 py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-amber-50 transition-all active:scale-[0.98] shadow-sm"
                >
                  <Truck className="w-5 h-5 text-orange-500" />
                  Acompanhar Pedido
                </button>
              </div>
            )}

            {orderState === 'tracking' && (
              <div className="animate-in slide-in-from-bottom-4 duration-500 space-y-4">
                <div className="bg-white border border-orange-100 p-6 rounded-[2rem] shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-orange-600">
                        <Clock className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-orange-400 uppercase">Tempo Estimado</p>
                        <p className="text-sm font-black text-gray-900">15 - 20 Minutos</p>
                      </div>
                    </div>
                  </div>

                  <div className="relative pt-2">
                    <div className="h-2 w-full bg-orange-50 rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 rounded-full w-[65%] animate-pulse" />
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => {
                    setOrderState('idle');
                    setPaymentMethod(null);
                    onClose();
                  }}
                  className="w-full text-orange-400 text-xs font-bold py-2 hover:text-orange-600 transition-colors flex items-center justify-center gap-1 group"
                >
                  Voltar para a Loja
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
